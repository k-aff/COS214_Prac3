#include "OpenField_Cavalry.h"

#include <iostream>
using namespace std; 

void OpenField_Cavalry::move()
{
    cout << "move() called from OpenField_Cavalry" << endl; 
}

void OpenField_Cavalry::attack()
{
    cout << "attack() called from OpenField_Cavalry" << endl; 
}