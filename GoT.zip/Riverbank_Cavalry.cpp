#include "Riverbank_Cavalry.h"

#include <iostream>
using namespace std; 

void Riverbank_Cavalry::move()
{
    cout << "move() called from Riverbank_Cavalry" << endl; 
}

void Riverbank_Cavalry::attack()
{
    cout << "attack() called from Riverbank_Cavalry" << endl; 
}