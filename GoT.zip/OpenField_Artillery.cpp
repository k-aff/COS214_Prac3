#include "OpenField_Artillery.h"

#include <iostream>
using namespace std; 

void OpenField_Artillery::move()
{
    cout << "move() called from OpenField_Artillery:" << endl; 
}

void OpenField_Artillery::attack()
{
    cout << "attack() called from OpenField_Artillery:" << endl; 
}