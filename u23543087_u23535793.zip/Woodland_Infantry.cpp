#include "Woodland_Infantry.h"

#include <iostream>
using namespace std; 

void Woodland_Infantry::move()
{
    cout << "move() called from Woodland_Infantry" << endl; 
}

void Woodland_Infantry::attack()
{
    cout << "attack() called from Woodland_Infantry" << endl; 
}