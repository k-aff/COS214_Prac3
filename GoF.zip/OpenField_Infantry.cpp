#include "OpenField_Infantry.h"

#include <iostream>
using namespace std; 

void OpenField_Infantry::move()
{
    cout << "move() called from OpenField_Infantry" << endl; 
}

void OpenField_Infantry::attack()
{
    cout << "attack() called from OpenField_Infantry" << endl; 
}