#include "Riverbank_Artillery.h"

#include <iostream>
using namespace std; 

void Riverbank_Artillery::move()
{
    cout << "move() called from Riverbank_Artillery" << endl; 
}

void Riverbank_Artillery::attack()
{
    cout << "attack() called from Riverbank_Artillery" << endl; 
}