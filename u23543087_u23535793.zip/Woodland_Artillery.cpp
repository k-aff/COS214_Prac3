#include "Woodland_Artillery.h"

#include <iostream>
using namespace std; 

void Woodland_Artillery::move()
{
    cout << "move() called from Woodland_Artillery" << endl; 
}

void Woodland_Artillery::attack()
{
    cout << "attack() called from Woodland_Artillery" << endl; 
}