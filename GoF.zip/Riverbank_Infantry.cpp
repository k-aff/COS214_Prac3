#include "Riverbank_Infantry.h"

#include <iostream>
using namespace std; 

void Riverbank_Infantry::move()
{
    cout << "move() called from Riverbank_Infantry" << endl; 
}

void Riverbank_Infantry::attack()
{
    cout << "attack() called from Riverbank_Infantry" << endl; 
}