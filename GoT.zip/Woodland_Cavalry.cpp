#include "Woodland_Cavalry.h"

#include <iostream>
using namespace std; 

void Woodland_Cavalry::move()
{
    cout << "move() called from Woodland_Cavalry" << endl; 
}

void Woodland_Cavalry::attack()
{
    cout << "attack() called from Woodland_Cavalry" << endl; 
}